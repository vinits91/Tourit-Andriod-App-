package phonebook.vinitshah.com.tourit;


import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import AdaptersPacakge.TabFragmentAdapter;
import Fragments.DescriptionFragment;
import Fragments.PhotosFragment;
import Fragments.VideoFragment;

public class TabActivity extends AppCompatActivity implements DescriptionFragment.OnFragmentInteractionListener, PhotosFragment.OnFragmentInteractionListener, VideoFragment.OnFragmentInteractionListener
        {

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private String[] tabs = { "Favourites", "PhotosFragment", "Videos" };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite2);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);


    }
    private void setupViewPager(ViewPager viewPager) {
        TabFragmentAdapter adapter = new TabFragmentAdapter(getSupportFragmentManager());
        adapter.addFragment(new DescriptionFragment(), "Description");
        adapter.addFragment(new PhotosFragment(), "Photos");
        adapter.addFragment(new VideoFragment(), "Videos");
        viewPager.setAdapter(adapter);
    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
