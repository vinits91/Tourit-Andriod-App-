package phonebook.vinitshah.com.tourit;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.CookieSyncManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.People;
import com.google.android.gms.plus.Plus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.CookieManager;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import helper.AppContext;
import helper.Attraction;
import helper.FavoritesDBHelper;

public class HomePage extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{


    private static final String FILE_TYPE = "images/*";
    TextView userName;
    TextView email;
    private ImageSwitcher sw;
    private ImageButton b1,b2;
    static int counter =0;
    FavoritesDBHelper favDB;
    static String imageTitle;
    TextView nameText;
    String personEmail;
    ImageView photo;
    ArrayList<Attraction> attractions;
    GoogleApiClient mGoogleApiClient;
    boolean mSignInClicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        favDB = new FavoritesDBHelper(this);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        SharedPreferences prefs = getSharedPreferences("tourit", 0);
        String personName = prefs.getString("personName", null);
        personEmail = prefs.getString("personEmail", null);
        //String personId = prefs.getString("personId", null);

        //Uri uri=Uri.parse(personPhoto);


        new Thread(new Runnable(){
            @Override
            public void run() {
                try {
                    try {
                        SharedPreferences prefs = getSharedPreferences("tourit", 0);
                        String personPhoto = prefs.getString("personPhoto", null);
                        if(personPhoto!=null) {
                            URL myUrl = new URL(personPhoto);
                            InputStream inputStream = (InputStream) myUrl.getContent();
                            Drawable drawable = Drawable.createFromStream(inputStream, null);
                            photo.setImageDrawable(drawable);
                        }else{
                            photo.setImageResource(R.drawable.default_avatar);;
                        }
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();

        if (getIntent().getBooleanExtra("EXIT", false)) {
            finish();
            return;
        }

        View hView =  navigationView.getHeaderView(0);
        userName=(TextView)hView.findViewById(R.id.userName);
        email=(TextView)hView.findViewById(R.id.email);
        photo=(ImageView)hView.findViewById(R.id.imageView);
        userName.setText(personName);
        email.setText(personEmail);
        //photo.setImageURI(uri);
        AppContext appContext=(AppContext)getApplicationContext();
        attractions=appContext.getAttractions();


        //System.out.println("===================Att=========="+attractions.get(0).getName());
        b1 = (ImageButton) findViewById(R.id.like);
        b2 = (ImageButton) findViewById(R.id.dislike);
        nameText=(TextView)findViewById(R.id.name);

        sw = (ImageSwitcher) findViewById(R.id.imageSwitcher);
        sw.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView myView = new ImageView(getApplicationContext());
                myView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                myView.setLayoutParams(new ImageSwitcher.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT));
                return myView;
            }
        });


        final Animation in = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        Animation out = AnimationUtils.loadAnimation(this,android.R.anim.slide_out_right);

        sw.setInAnimation(in);
        sw.setOutAnimation(out);
        if(counter < attractions.size()-1) {
            nameText.setText(attractions.get(counter).getName());
            imageTitle = attractions.get(counter).getPicture();
            sw.setImageResource(getResources().getIdentifier(imageTitle, "drawable", getPackageName()));
        }

        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Attraction atr = attractions.get(counter);
                Intent intent = new Intent(HomePage.this, TabActivity.class);
                intent.putExtra("attraction", atr);
                startActivity(intent);
            }

        });
    }



    public void likeAction(View view){
        if(counter < attractions.size()-1){
            favDB.insertFavorites(personEmail, attractions.get(counter).getId(),attractions.get(counter).getName());
            counter ++;
            nameText.setText(attractions.get(counter).getName());
            imageTitle = attractions.get(counter).getPicture();
            sw.setImageResource(getResources().getIdentifier(imageTitle, "drawable", getPackageName()));
        }
        else{
            favDB.insertFavorites(personEmail, attractions.get(counter).getId(),attractions.get(counter).getName());
            counter=0;
            nameText.setText(attractions.get(counter).getName());
            imageTitle = attractions.get(counter).getPicture();
            sw.setImageResource(getResources().getIdentifier(imageTitle, "drawable", getPackageName()));
            Toast.makeText(getApplicationContext(), "You have viewed all Attractions.", Toast.LENGTH_LONG).show();
        }


    }

    public void dislikeAction(View view){
        if(counter < attractions.size()-1){
            counter ++;
            nameText.setText(attractions.get(counter).getName());
            imageTitle = attractions.get(counter).getPicture();
            sw.setImageResource(getResources().getIdentifier(imageTitle, "drawable", getPackageName()));
        }
        else{
            Toast.makeText(getApplicationContext(), "No more Attractions", Toast.LENGTH_LONG).show();
        }

    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(HomePage.this, HomePage.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("EXIT", true);
        startActivity(intent);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_page, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (item.getItemId()) {

            case R.id.menu_item_share:

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                shareIntent.setType("image/*");

                // For a file in shared storage.  For data in private storage, use a ContentProvider.
                imageTitle = attractions.get(counter).getPicture();
                int ident=getResources().getIdentifier(imageTitle, "drawable", getPackageName());
                Uri path = Uri.parse("android.resource://"+getPackageName()+"/" + ident);
                shareIntent.putExtra(Intent.EXTRA_STREAM, path);
                String shareBody = imageTitle+": \n"+attractions.get(counter).getDescription()+"\n\nDownload TourIt, an easy way to plan your trip";
                shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "TourIt, a Trip made Easy !!");
                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(

                        shareIntent,

                        "Share Via"));

                break;

        }

        //noinspection SimplifiableIfStatement
        /*if (id == R.id.action_settings) {
            return true;
        }
*/
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(takePictureIntent, 1888);
        } else if (id == R.id.nav_gallery) {
            Intent intent=new Intent(this,TabActivity.class);
            intent.putExtra("tab",1);
            intent.putExtra("def",0);
            startActivity(intent);

        } else if (id == R.id.nav_slideshow) {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("video/*");
            startActivityForResult(intent , 3);
        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.favourite) {

        } else if (id == R.id.nav_logout) {

        } else if (id == R.id.nav_share) {
            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBody = "Download TourIt, an easy way to plan your trip";
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "TourIt, a Trip made Easy !!");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share via"));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1888 && resultCode == RESULT_OK) {
            if (data != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                String currentDateandTime = sdf.format(new Date());
                String fileName=currentDateandTime+".jpg";
                File direct = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/TourIt");
                if (!direct.exists()) {
                    File wallpaperDirectory = new File("/sdcard/TourIt/");
                    wallpaperDirectory.mkdirs();
                }

                // get the photo from intent
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                File file = new File(new File("/sdcard/TourIt/"), fileName);
                if (file.exists()) {
                    file.delete();
                }
                try {
                    FileOutputStream out = new FileOutputStream(file);
                    photo.compress(Bitmap.CompressFormat.JPEG, 100, out);
                    out.flush();
                    out.close();
                    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    File f = new File(file.getPath());
                    Uri contentUri = Uri.fromFile(f);
                    mediaScanIntent.setData(contentUri);
                    this.sendBroadcast(mediaScanIntent);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }

}
