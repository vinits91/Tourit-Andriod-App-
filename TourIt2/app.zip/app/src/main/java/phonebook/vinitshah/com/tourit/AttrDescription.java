package phonebook.vinitshah.com.tourit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import helper.Attraction;

public class AttrDescription extends AppCompatActivity {
    Attraction Attr;
    TextView name;
    TextView dscp;
    WebView wv;
    Button gotomap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attr_description);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);


        Intent intent = getIntent();
        Attr = (Attraction) intent.getExtras().getSerializable("Attr");

        // final LatLng detn = new LatLng(Attr.getLatitude(),Attr.getLongitude());
        final String[] dstn = new String[3];
        dstn[0]= String.valueOf(Attr.getLatitude());
        dstn[1]= String.valueOf(Attr.getLongitude());
        dstn[2]= String.valueOf(Attr.getName());
        toolbar.setTitle(Attr.getName());
        setSupportActionBar(toolbar);





        gotomap =(Button) findViewById(R.id.route);


        dscp = (TextView) findViewById(R.id.desc);
        dscp.setText(Attr.getDescription());
        name = (TextView) findViewById(R.id.Des_name);
        name.setText(Attr.getName());
        wv = (WebView) findViewById(R.id.Des_webView);

        String link =Attr.getVideoLink().toString();
        link.replace("watch?v=","embed/");
        System.out.println(link);


        String frameVideo = "<html><body><iframe width=\"320\" height=\"200\" src=\""+link+"\""+" frameborder=\"0\" allowfullscreen></iframe></body></html>";;

        // String frameVideo = "<html><body><iframe width=\"320\" height=\"200\" src=\"+\"+link+\" frameborder=\"0\" allowfullscreen></iframe></body></html>";
        //  System.out.println(frameVideo);

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });
        WebSettings webSettings = wv.getSettings();
        webSettings.setJavaScriptEnabled(true);
        wv.loadData(frameVideo, "text/html", "utf-8");



        gotomap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                Intent intent = new Intent(AttrDescription.this, MapsGuestActivity.class);
                intent.putExtra("dstn",dstn);
                startActivity(intent);

            }
        });

    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        wv = (WebView) findViewById(R.id.Des_webView);

        if(keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME){
            wv.destroy();
        }

        return super.onKeyDown(keyCode, event);
    }

}
